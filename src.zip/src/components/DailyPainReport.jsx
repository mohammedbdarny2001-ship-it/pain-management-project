import { useState } from "react";

export default function DailyPainReport() {
  const [painLevel, setPainLevel] = useState(5);
  const [location, setLocation] = useState("Back");
  const [painType, setPainType] = useState("Burning");
  const [duration, setDuration] = useState("");
  const [medicationTaken, setMedicationTaken] = useState("No");
  const [notes, setNotes] = useState("");
  const [submittedReport, setSubmittedReport] = useState(null);

  function handleSubmit(event) {
    event.preventDefault();

    const report = {
      painLevel,
      location,
      painType,
      duration: duration || "Not specified",
      medicationTaken,
      notes,
    };

    setSubmittedReport(report);
  }

  return (
    <section id="pain-report" className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white rounded-2xl shadow p-6">
        <div className="flex items-center justify-between gap-4 mb-6">
          <h2 className="text-2xl font-bold text-slate-800">
            Daily Pain Report
          </h2>

          <span className="px-3 py-1 rounded-full bg-blue-100 text-blue-700 text-sm">
            Patient Screen
          </span>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block font-semibold text-slate-700 mb-2">
              Pain intensity: <span className="text-blue-700">{painLevel}</span>/10
            </label>

            <input
              type="range"
              min="0"
              max="10"
              value={painLevel}
              onChange={(event) => setPainLevel(event.target.value)}
              className="w-full"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-2">
                Pain location
              </label>

              <select
                value={location}
                onChange={(event) => setLocation(event.target.value)}
                className="w-full border border-slate-300 rounded-lg px-3 py-2"
              >
                <option>Back</option>
                <option>Neck</option>
                <option>Leg</option>
                <option>Arm</option>
                <option>Head</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-2">
                Pain type
              </label>

              <select
                value={painType}
                onChange={(event) => setPainType(event.target.value)}
                className="w-full border border-slate-300 rounded-lg px-3 py-2"
              >
                <option>Burning</option>
                <option>Pressing</option>
                <option>Stabbing</option>
                <option>Numbness</option>
                <option>Other</option>
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-2">
                Duration
              </label>

              <input
                type="text"
                value={duration}
                onChange={(event) => setDuration(event.target.value)}
                placeholder="Example: 45 minutes"
                className="w-full border border-slate-300 rounded-lg px-3 py-2"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-2">
                Medication taken?
              </label>

              <select
                value={medicationTaken}
                onChange={(event) => setMedicationTaken(event.target.value)}
                className="w-full border border-slate-300 rounded-lg px-3 py-2"
              >
                <option>No</option>
                <option>Yes</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-2">
              Notes
            </label>

            <textarea
              value={notes}
              onChange={(event) => setNotes(event.target.value)}
              placeholder="Write short notes about today's pain..."
              rows="4"
              className="w-full border border-slate-300 rounded-lg px-3 py-2"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-blue-700 hover:bg-blue-800 text-white font-semibold py-3 rounded-lg"
          >
            Submit Pain Report
          </button>
        </form>
      </div>

      <div className="space-y-6">
        {submittedReport && (
          <div className="bg-white rounded-2xl shadow p-6 border-l-4 border-green-500">
            <h3 className="text-xl font-bold text-green-700 mb-3">
              Report Submitted
            </h3>

            <p className="text-slate-600">
              Pain report saved: level {submittedReport.painLevel}/10,
              location: {submittedReport.location}, type:{" "}
              {submittedReport.painType}, duration:{" "}
              {submittedReport.duration}, medication taken:{" "}
              {submittedReport.medicationTaken}.
            </p>
          </div>
        )}

        {painLevel >= 8 && (
          <div className="bg-red-50 rounded-2xl shadow p-6 border border-red-200">
            <h3 className="text-xl font-bold text-red-700 mb-3">
              High Pain Alert
            </h3>

            <p className="text-red-700 mb-4">
              Pain level is 8 or higher. Please follow your clinic instructions
              and contact the clinic if needed.
            </p>

            <button className="bg-red-600 text-white px-5 py-2 rounded-lg">
              Contact Clinic
            </button>
          </div>
        )}
      </div>
    </section>
  );
}