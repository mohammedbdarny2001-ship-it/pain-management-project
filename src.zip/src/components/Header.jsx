export default function Header() {
  return (
    <header className="bg-white shadow-sm border-b border-slate-200">
      <div className="max-w-6xl mx-auto px-6 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-blue-700">
            PainCare Assistant
          </h1>
          <p className="text-sm text-slate-500">
            Initial React Component Prototype - Pain Clinic B12
          </p>
        </div>

        <nav className="flex flex-wrap gap-2">
          <a href="#pain-report" className="px-3 py-2 rounded-lg bg-blue-50 text-blue-700 text-sm font-medium">
            Pain Report
          </a>
          <a href="#chatbot" className="px-3 py-2 rounded-lg bg-purple-50 text-purple-700 text-sm font-medium">
            Chatbot
          </a>
          <a href="#dashboard" className="px-3 py-2 rounded-lg bg-green-50 text-green-700 text-sm font-medium">
            Doctor Dashboard
          </a>
          <a href="#trends" className="px-3 py-2 rounded-lg bg-slate-100 text-slate-700 text-sm font-medium">
            Trends
          </a>
        </nav>
      </div>
    </header>
  );
}