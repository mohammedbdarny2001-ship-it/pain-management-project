import { patients } from "../data/fakeData";

export default function DoctorDashboard() {
  const totalPatients = patients.length;
  const highPainAlerts = patients.filter((patient) => patient.lastPain >= 8).length;

  const averagePain = (
    patients.reduce((sum, patient) => sum + patient.lastPain, 0) / totalPatients
  ).toFixed(1);

  return (
    <section id="dashboard" className="bg-white rounded-2xl shadow p-6">
      <div className="flex items-center justify-between gap-4 mb-6">
        <h2 className="text-2xl font-bold text-slate-800">
          Doctor Dashboard
        </h2>

        <span className="px-3 py-1 rounded-full bg-green-100 text-green-700 text-sm">
          Medical Staff Screen
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-blue-50 rounded-xl p-4">
          <p className="text-sm text-slate-500">Total Patients</p>
          <p className="text-3xl font-bold text-blue-700">
            {totalPatients}
          </p>
        </div>

        <div className="bg-red-50 rounded-xl p-4">
          <p className="text-sm text-slate-500">High Pain Alerts</p>
          <p className="text-3xl font-bold text-red-700">
            {highPainAlerts}
          </p>
        </div>

        <div className="bg-green-50 rounded-xl p-4">
          <p className="text-sm text-slate-500">Average Pain Level</p>
          <p className="text-3xl font-bold text-green-700">
            {averagePain}
          </p>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-100 text-slate-600">
              <th className="p-3">Patient</th>
              <th className="p-3">Diagnosis</th>
              <th className="p-3">Last Pain</th>
              <th className="p-3">Medication</th>
              <th className="p-3">Status</th>
            </tr>
          </thead>

          <tbody>
            {patients.map((patient) => {
              const isHighAlert = patient.lastPain >= 8;

              return (
                <tr key={patient.id} className="border-b hover:bg-slate-50">
                  <td className="p-3 font-medium text-slate-800">
                    {patient.name}
                  </td>

                  <td className="p-3 text-slate-600">
                    {patient.diagnosis}
                  </td>

                  <td className="p-3">
                    <span
                      className={
                        isHighAlert
                          ? "px-3 py-1 rounded-full bg-red-100 text-red-700 font-medium"
                          : "px-3 py-1 rounded-full bg-green-100 text-green-700 font-medium"
                      }
                    >
                      {patient.lastPain}/10
                    </span>
                  </td>

                  <td className="p-3 text-slate-600">
                    {patient.medication}
                  </td>

                  <td className="p-3 text-slate-600">
                    {patient.status}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}