import { weeklyPainData } from "../data/fakeData";

export default function PainTrends() {
  return (
    <section id="trends" className="bg-white rounded-2xl shadow p-6">
      <h2 className="text-2xl font-bold text-slate-800 mb-3">
        Pain Trends Summary
      </h2>

      <p className="text-slate-600 mb-6">
        Simple weekly pain trend visualization based on fake patient data.
      </p>

      <div className="flex items-end gap-4 h-64 bg-slate-50 rounded-xl p-4">
        {weeklyPainData.map((item) => {
          const barHeight = item.level * 18;

          return (
            <div key={item.day} className="flex-1 flex flex-col items-center gap-2">
              <span className="text-sm font-semibold text-slate-700">
                {item.level}
              </span>

              <div
                className="w-full bg-blue-600 rounded-t-lg"
                style={{ height: `${barHeight}px` }}
              ></div>

              <span className="text-xs text-slate-500">
                {item.day}
              </span>
            </div>
          );
        })}
      </div>
    </section>
  );
}