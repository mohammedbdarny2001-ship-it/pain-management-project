import { useState } from "react";

export default function PainAssistantChatbot() {
  const [messages, setMessages] = useState([
    {
      sender: "Assistant",
      text: "Hello, I am here to help you manage your pain. How are you feeling today?",
    },
  ]);

  function handleQuickAnswer(answer) {
    let assistantResponse = "";

    if (answer === "Much better") {
      assistantResponse =
        "That is good to hear. Please continue tracking your pain so the clinic can follow your progress.";
    } else if (answer === "Same as yesterday") {
      assistantResponse =
        "Thank you for the update. Please keep documenting your symptoms regularly.";
    } else if (answer === "Worse than usual") {
      assistantResponse =
        "I understand. Please submit a daily pain report so the medical staff can review the change.";
    } else if (answer === "Pain is severe") {
      assistantResponse =
        "I am sorry you are experiencing severe pain. Please follow your clinic instructions and consider contacting the clinic.";
    }

    setMessages((previousMessages) => [
      ...previousMessages,
      {
        sender: "Patient",
        text: answer,
      },
      {
        sender: "Assistant",
        text: assistantResponse,
      },
    ]);
  }

  return (
    <section id="chatbot" className="bg-white rounded-2xl shadow p-6">
      <div className="flex items-center justify-between gap-4 mb-6">
        <h2 className="text-2xl font-bold text-slate-800">
          Pain Assistant Chatbot
        </h2>

        <span className="px-3 py-1 rounded-full bg-purple-100 text-purple-700 text-sm">
          React useState Interaction
        </span>
      </div>

      <div className="bg-slate-50 rounded-xl p-4 h-80 overflow-y-auto space-y-4 mb-4">
        {messages.map((message, index) => (
          <div
            key={index}
            className={
              message.sender === "Patient"
                ? "ml-auto max-w-xl bg-blue-700 text-white rounded-xl p-4"
                : "mr-auto max-w-xl bg-white text-slate-700 rounded-xl p-4 shadow-sm"
            }
          >
            <p className="text-sm opacity-80 mb-1">{message.sender}</p>
            <p>{message.text}</p>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-3">
        <button
          onClick={() => handleQuickAnswer("Much better")}
          className="px-4 py-2 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800"
        >
          Much better
        </button>

        <button
          onClick={() => handleQuickAnswer("Same as yesterday")}
          className="px-4 py-2 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800"
        >
          Same as yesterday
        </button>

        <button
          onClick={() => handleQuickAnswer("Worse than usual")}
          className="px-4 py-2 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800"
        >
          Worse than usual
        </button>

        <button
          onClick={() => handleQuickAnswer("Pain is severe")}
          className="px-4 py-2 rounded-lg bg-red-100 hover:bg-red-200 text-red-700"
        >
          Pain is severe
        </button>
      </div>
    </section>
  );
}