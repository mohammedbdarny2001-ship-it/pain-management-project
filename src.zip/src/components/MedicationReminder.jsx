import { medicationReminder } from "../data/fakeData";

export default function MedicationReminder() {
  return (
    <section className="bg-white rounded-2xl shadow p-6">
      <h2 className="text-2xl font-bold text-slate-800 mb-4">
        Medication Reminder
      </h2>

      <p className="text-slate-600 mb-4">
        Next medication reminder based on fake data:
      </p>

      <div className="border border-yellow-300 bg-yellow-50 rounded-xl p-4 flex items-center justify-between">
        <span className="font-semibold text-slate-800">
          {medicationReminder.name}
        </span>

        <span className="font-bold text-orange-700">
          {medicationReminder.time}
        </span>
      </div>
    </section>
  );
}