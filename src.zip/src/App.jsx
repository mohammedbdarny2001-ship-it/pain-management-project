import Header from "./components/Header";
import DailyPainReport from "./components/DailyPainReport";
import MedicationReminder from "./components/MedicationReminder";
import PainAssistantChatbot from "./components/PainAssistantChatbot";
import DoctorDashboard from "./components/DoctorDashboard";
import PainTrends from "./components/PainTrends";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-100 text-slate-800">
      <Header />

      <main className="max-w-6xl mx-auto px-6 py-8 space-y-8">
        <section className="bg-white rounded-2xl shadow p-6">
          <h2 className="text-2xl font-bold text-slate-800 mb-3">
            System Overview
          </h2>

          <p className="text-slate-600 leading-relaxed">
            PainCare Assistant is an initial React-based prototype for a pain
            management web application. The system allows patients to submit
            daily pain reports, interact with a pain assistant chatbot, receive
            medication reminders, and view pain trends. It also provides medical
            staff with a doctor dashboard that displays patient summaries,
            abnormal pain alerts, and fake patient data.
          </p>
        </section>

        <DailyPainReport />

        <MedicationReminder />

        <PainAssistantChatbot />

        <DoctorDashboard />

        <PainTrends />
      </main>

      <footer className="text-center text-sm text-slate-500 py-6">
        B12 PainCare Assistant Project - React Component Prototype
      </footer>
    </div>
  );
}