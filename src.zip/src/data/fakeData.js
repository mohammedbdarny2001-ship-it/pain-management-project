export const patients = [
  {
    id: 1,
    name: "Miriam Cohen",
    diagnosis: "Chronic back pain",
    lastPain: 8,
    medication: "Yes",
    status: "High Alert",
  },
  {
    id: 2,
    name: "David Levi",
    diagnosis: "Neuropathic pain",
    lastPain: 5,
    medication: "No",
    status: "Stable",
  },
  {
    id: 3,
    name: "Roni Levy",
    diagnosis: "Neck disc pain",
    lastPain: 7,
    medication: "Yes",
    status: "Needs Follow-up",
  },
  {
    id: 4,
    name: "Sara Haddad",
    diagnosis: "Leg pain",
    lastPain: 3,
    medication: "No",
    status: "Stable",
  },
];

export const weeklyPainData = [
  { day: "Sun", level: 6 },
  { day: "Mon", level: 7 },
  { day: "Tue", level: 5 },
  { day: "Wed", level: 8 },
  { day: "Thu", level: 6 },
  { day: "Fri", level: 4 },
  { day: "Sat", level: 5 },
];

export const medicationReminder = {
  name: "Painkiller dose",
  time: "20:00",
};